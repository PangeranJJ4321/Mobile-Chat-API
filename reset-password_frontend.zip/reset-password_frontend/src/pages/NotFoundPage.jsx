import React from 'react';
import { useNavigate } from 'react-router-dom';

const NotFoundPage = () => {
    const navigate = useNavigate();

    return (
        <div className="min-h-screen flex flex-col items-center justify-center bg-gradient-to-br from-purple-100 to-blue-100 p-4">
            <div className="bg-white p-10 rounded-2xl shadow-2xl w-full max-w-md text-center">
                <h1 className="text-6xl font-extrabold text-purple-600 mb-2">404</h1>
                <h2 className="text-2xl font-semibold text-gray-800 mb-4">Oops! Halaman tidak ditemukan 😢</h2>
                <p className="text-gray-600 mb-6">
                    Maaf ya sayang, sepertinya kamu nyasar ke halaman yang nggak ada~
                </p>
                <button
                    onClick={() => navigate('/')}
                    className="bg-purple-600 hover:bg-purple-700 text-white font-semibold py-3 px-6 rounded-full transition duration-200"
                >
                    Balik ke Beranda Yuk 💜
                </button>
            </div>
        </div>
    );
};

export default NotFoundPage;

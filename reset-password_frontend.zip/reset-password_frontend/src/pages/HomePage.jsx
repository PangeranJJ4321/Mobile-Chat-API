import React from 'react';
import { useNavigate } from 'react-router-dom';
import ChatOILogo from '../components/ChatOILogo';

const HomePage = () => {
    const navigate = useNavigate();

    return (
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-100 to-indigo-200 p-4">
            <div className="bg-white p-10 rounded-xl shadow-xl w-full max-w-md text-center">
                <ChatOILogo size={72} />
                <h1 className="text-3xl font-bold text-indigo-700 mb-4">Terima kasih sudah reset password 💌</h1>
                <p className="text-gray-700 mb-6">Silakan login kembali ke aplikasi <strong>ChatOI</strong> yaa~</p>
                <button
                    onClick={() => navigate('/login')}
                    className="bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-6 rounded-lg transition duration-200"
                >
                    Ayo Login Lagi 💬
                </button>
            </div>
        </div>
    );
};

export default HomePage;

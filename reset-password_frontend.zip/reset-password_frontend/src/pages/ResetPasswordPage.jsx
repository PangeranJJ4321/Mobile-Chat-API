import React, { useState, useEffect } from 'react';
import { useSearchParams, useNavigate } from 'react-router-dom';
import { resetPassword } from '../services/authService';
import axios from 'axios';
import ChatOILogo from '../components/ChatOILogo';
import { Eye, EyeOff } from 'lucide-react'; 

const API_URL = 'http://192.168.43.43:8000';

const ResetPasswordPage = () => {
    const [searchParams] = useSearchParams();
    const navigate = useNavigate();
    const [token, setToken] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    const [showNew, setShowNew] = useState(false);
    const [showConfirm, setShowConfirm] = useState(false);
    const [message, setMessage] = useState('');
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);
    const [showSuccessMessage, setShowSuccessMessage] = useState(false);
    const [isTokenValid, setIsTokenValid] = useState(false);
    const [initialLoading, setInitialLoading] = useState(true);

    useEffect(() => {
        const resetToken = searchParams.get('token');
        if (resetToken) {
            setToken(resetToken);
            const validateToken = async () => {
                try {
                    await axios.get(`${API_URL}/api/auth/validate-reset-token?token=${resetToken}`);
                    setIsTokenValid(true);
                } catch (err) {
                    if (err.response && (err.response.status === 400 || err.response.status === 404)) {
                        navigate('/404', { replace: true });
                    } else {
                        setError('Gagal validasi token. Coba lagi yaa 😔');
                        setIsTokenValid(false);
                    }
                } finally {
                    setInitialLoading(false);
                }
            };
            validateToken();
        } else {
            navigate('/404', { replace: true });
        }
    }, [searchParams, navigate]);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setMessage('');
        setError('');
        setShowSuccessMessage(false);

        if (!token || !isTokenValid) {
            setError('Token tidak valid atau kadaluarsa.');
            return;
        }

        if (newPassword !== confirmPassword) {
            setError('Password dan konfirmasi tidak cocok 😢');
            return;
        }

        if (newPassword.length < 6) {
            setError('Password minimal 6 karakter ya cinta 😘');
            return;
        }

        setLoading(true);
        try {
            const response = await resetPassword(token, newPassword);
            setMessage(response.message || 'Password berhasil direset!');
            setShowSuccessMessage(true);
        } catch (err) {
            if (err.message.includes("Invalid or expired reset token")) {
                navigate('/404', { replace: true });
            } else {
                setError(err.message || 'Gagal reset password. Coba lagi yaa.');
            }
        } finally {
            setLoading(false);
        }
    };

    if (initialLoading) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gray-100 p-4">
                <div className="text-xl font-semibold text-gray-700">Loading...</div>
            </div>
        );
    }

    if (showSuccessMessage) {
        return (
            <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-pink-100 to-red-200 p-4">
                <div className="bg-white p-8 rounded-xl shadow-xl w-full max-w-md text-center">
                    <ChatOILogo size={64} />
                    <h2 className="text-2xl font-bold text-green-600 mb-4">Password Berhasil Diubah 🎉</h2>
                    <p className="text-gray-700 mb-6">Silakan login kembali ya di aplikasi ChatOI 💌</p>
                    <button
                        onClick={() => navigate('/')}
                        className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg transition duration-200"
                    >
                        Ayo Login Sekarang
                    </button>
                </div>
            </div>
        );
    }

    return (
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-rose-200 via-red-300 to-pink-300 p-4">
            <div className="bg-white p-8 rounded-xl shadow-xl w-full max-w-md w-[90%] sm:w-full">
                <ChatOILogo size={72} />
                <h2 className="text-xl sm:text-2xl font-bold text-center text-red-700 mb-6">Reset Password Kamu 💌</h2>

                <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="relative">
                        <label className="block text-sm font-medium text-gray-700 mb-1">Password Baru</label>
                        <input
                            type={showNew ? 'text' : 'password'}
                            className="w-full px-4 py-3 border rounded-lg shadow-sm pr-12 focus:outline-none focus:ring-2 focus:ring-red-500"
                            value={newPassword}
                            onChange={(e) => setNewPassword(e.target.value)}
                            required
                        />
                        <button
                            type="button"
                            onClick={() => setShowNew(!showNew)}
                            className="absolute right-3 top-9 text-gray-500 hover:text-gray-700"
                        >
                            {showNew ? <EyeOff size={20} /> : <Eye size={20} />}
                        </button>
                    </div>

                    <div className="relative">
                        <label className="block text-sm font-medium text-gray-700 mb-1">Konfirmasi Password</label>
                        <input
                            type={showConfirm ? 'text' : 'password'}
                            className="w-full px-4 py-3 border rounded-lg shadow-sm pr-12 focus:outline-none focus:ring-2 focus:ring-red-500"
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                            required
                        />
                        <button
                            type="button"
                            onClick={() => setShowConfirm(!showConfirm)}
                            className="absolute right-3 top-9 text-gray-500 hover:text-gray-700"
                        >
                            {showConfirm ? <EyeOff size={20} /> : <Eye size={20} />}
                        </button>
                    </div>

                    <button
                        type="submit"
                        disabled={loading}
                        className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-3 rounded-lg transition duration-200 disabled:bg-gray-400"
                    >
                        {loading ? 'Memproses...' : 'Reset Password'}
                    </button>
                    {message && <p className="text-green-600 font-medium text-center">{message}</p>}
                    {error && <p className="text-red-600 font-medium text-center">{error}</p>}
                </form>
            </div>
        </div>
    );
};

export default ResetPasswordPage;

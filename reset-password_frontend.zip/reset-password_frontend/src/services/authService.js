import axios from 'axios';

const API_URL = 'http://192.168.43.43:8000'; 

export const resetPassword = async (token, newPassword) => {
    try {
        const response = await axios.post(`${API_URL}/api/auth/reset-password`, {
            token,
            new_password: newPassword,
        });
        return response.data;
    } catch (error) {
        if (error.response) {
            throw new Error(error.response.data.detail || 'Something went wrong.');
        } else if (error.request) {
            throw new Error('No response from server. Please check your network.');
        } else {
            throw new Error(error.message || 'An unexpected error occurred.');
        }
    }
};

// ... other authentication functions like login, register, etc.


const ChatOILogo = ({ size = 200 }) => {
    return (
        <div
            className="rounded-full shadow-lg overflow-hidden mx-auto mb-6 border-4 border-white"
            style={{ width: size, height: size }}
        >
            <img
                src={"https://res.cloudinary.com/douoytv3i/image/upload/v1747110395/x3uzyjsocnq6g9soismk.png"}
                alt="ChatOI Logo"
                className="w-full h-full object-cover"
            />
        </div>
    );
};

export default ChatOILogo;

